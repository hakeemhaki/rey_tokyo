<div class="rey-siteFooter-container">
	<div class="rey-siteFooter-row">

		<?php
		/**
		 * Prints content inside footer's main row
		 * @hook rey/header/row
		 */
		rey_action__footer_row(); ?>

	</div>
</div>
