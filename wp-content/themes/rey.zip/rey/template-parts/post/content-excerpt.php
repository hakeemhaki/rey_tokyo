<div class="rey-postContent">
	<?php
		the_excerpt();

		rey__excerptFooter_before();
		rey__excerptFooter();
		rey__excerptFooter_after();
	?>
</div><!-- .rey-postContent -->
